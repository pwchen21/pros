from distutils.core import setup
setup (
        name = 'module_test2',
        version = '0.0.3',
        py_modules = ['module_test2'],
        author = 'tester',
        author_email = 'test@gmail.com',
        url = 'http://111.test',
        description = 'this a module test practice, pleaset do not use'
    )
