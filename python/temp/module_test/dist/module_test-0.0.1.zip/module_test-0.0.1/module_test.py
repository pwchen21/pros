for x in list:
	print(x)